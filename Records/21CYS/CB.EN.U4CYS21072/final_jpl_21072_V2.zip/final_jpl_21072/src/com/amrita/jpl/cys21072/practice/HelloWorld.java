package com.amrita.jpl.cys21072.practice;
/**
 * @author Sri Sai Tanvi Sonti CB.EN.U4CYS21072
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}