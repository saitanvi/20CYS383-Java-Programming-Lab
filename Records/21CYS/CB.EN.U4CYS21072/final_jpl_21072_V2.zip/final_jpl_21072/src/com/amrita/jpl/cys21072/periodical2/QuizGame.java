package com.amrita.jpl.cys21072.periodical2;

/**
 * @author Sri Sai Tanvi Sonti CB.EN.U4CYS21072
 */

public abstract class QuizGame {
    public abstract void startGame();
    public abstract void askQuestion();
    public abstract void evaluateAnswer(String answer);
}

