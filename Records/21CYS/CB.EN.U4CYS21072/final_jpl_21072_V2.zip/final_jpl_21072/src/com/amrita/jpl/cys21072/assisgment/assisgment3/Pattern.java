package com.amrita.jpl.cys21072.assisgment.assisgment3;

/**
 * @author Sri Sai Tanvi Sonti CB.EN.U4CYS21072
 */
public class Pattern {
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ==================================");
        }
        for (int i = 0; i < 6; i++) {
            System.out.println("==============================================");
         }
    }
}