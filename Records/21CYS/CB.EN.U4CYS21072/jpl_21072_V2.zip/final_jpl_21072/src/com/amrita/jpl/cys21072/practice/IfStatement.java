package com.amrita.jpl.cys21072.practice;
/**
 * @author Sri Sai Tanvi Sonti CB.EN.U4CYS21072
 */
class IfStatement {
    public static void main(String[] args) {

        int number = 10;


        if (number < 0) {
            System.out.println("The number is negative.");
        }

        System.out.println("Statement outside if block");
    }
}
