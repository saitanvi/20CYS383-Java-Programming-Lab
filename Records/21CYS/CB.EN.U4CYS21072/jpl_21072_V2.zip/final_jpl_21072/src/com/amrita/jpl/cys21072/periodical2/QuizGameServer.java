package com.amrita.jpl.cys21072.periodical2;

import java.io.*;
import java.net.*;

/**
 * @author Sri Sai Tanvi Sonti CB.EN.U4CYS21072
 */
public class QuizGameServer {

    public static void main(String[] args) {
        try {

            ServerSocket ss = new ServerSocket(6666);


            Socket s = ss.accept();


            DataInputStream dis = new DataInputStream(s.getInputStream());


            String str = dis.readUTF();
            System.out.println("Message: " + str);


            ss.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
}
