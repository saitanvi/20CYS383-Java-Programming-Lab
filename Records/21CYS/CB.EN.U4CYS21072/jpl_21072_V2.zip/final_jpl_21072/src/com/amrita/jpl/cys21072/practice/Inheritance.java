package com.amrita.jpl.cys21072.practice;

class Animal {

    /**
     * @author Sri Sai Tanvi Sonti CB.EN.U4CYS21072
     */
    String name;
    public void bite() {
        System.out.println("I can bite");
        System.out.println("I will bite");
    }
}

class Dog extends Animal {
    public void display() {
        System.out.println("My name is " + name);
    }
}

class Main {
    public static void main(String[] args) {


        Dog labrador = new Dog();


        labrador.name = "Rio";
        labrador.display();


        labrador.bite();

    }
}
