package com.amrita.jpl.cys21072.periodical2;


import java.util.Random;
/**
 * @author Sri Sai Tanvi Sonti
 * Starts the quiz game.
 * Given task is to create a simple inline quiz game
 * The game consist of a server program and single client programs.
 */

public abstract class p2{
    public abstract void startGame();
    abstract void askQuestion();
    /**
     * Evaluates the player's answer.
     *
     * @param answer the answer provided by the player
     */
    abstract void evaluateAnswer(String answer);
}

interface QuizGameListener{
    /**
     * Called when a question is asked.
     *
     * @param question the question asked by the server
     */
    void onQuestionAsked(String question);
    /**
     * Called when the answer is evaluated.
     *
     * @param isCorrect true if the answer is correct, false otherwise
     */
    void onAnswerEvaluation(boolean isCorrect);
}

//This class implements server-side functionality.
// QuizGameServer class implementing QuizGame
class QuizGameServer extends QuizGame {
    private QuizGameListener listener;

    public QuizGameServer(QuizGameListener listener) {
        this.listener = listener;
    }


    public void startGame() {
        askQuestion();
    }


    public void askQuestion() {

        String question = getRandomQuestion();
        listener.onQuestionAsked(question);
    }

    public void evaluateAnswer(String answer) {
        boolean isCorrect = true;

        listener.OnevaluateAnswer(isCorrect);
    }

    private String getRandomQuestion() {
        String[] questions = {
                "What is the capital of India?",
        };
        int index = new Random().nextInt(questions.length);
        return questions[index];
    }
}


class QuizGameClient extends QuizGame {
    private QuizGameListener listener;

    public QuizGameClient(QuizGameListener listener) {
        this.listener = listener;
    }


    public void startGame() {
        connectToServer();
        askQuestion();
    }


    public void askQuestion() {
        String question = receiveQuestion();
        System.out.println("Question: " + question);
    }

    public void evaluateAnswer(String answer) {
        sendAnswer(answer);
        boolean isCorrect = receiveResult();
        System.out.println("Answer evaluated: " + (isCorrect ? "Correct" : "Incorrect"));
    }

    private void connectToServer(){}
    private String receiveQuestion() {
        return "Number of stated in India?";
    }

    private void sendAnswer(String answer) {}
    private boolean receiveResult () {
        return true;
    }
}
public class Main {
    public static void main(String[] args) {
        QuizGameListener listener = new QuizGameListener() {
            public void onQuestionAsked(String question) {
                System.out.println("Server asked: " + question);
            }
            public void onAnswerEvaluated(boolean isCorrect) {
                System.out.println("Answer evaluated: " + (isCorrect ? "Correct" : "Incorrect"));
            }
        };
        QuizGameServer server = new QuizGameServer(listener);
        QuizGameClient client = new QuizGameClient(listener);
        server.startGame();
        client.startGame();
    }
}



